import tkinter as tk
from tkinter import simpledialog, messagebox
import time

MAX_FILES = 24
ALLOWED_EXTS = ['.txt', '.pdf']
files = {}
file_positions = {}
settings = {"dark_mode": False}
s_mode_enabled = False

def show_login():
    login_win = tk.Toplevel()
    login_win.title("Login to GrayscaleTyperOS")
    login_win.geometry("300x220")
    login_win.resizable(False, False)
    login_win.protocol("WM_DELETE_WINDOW", root.destroy)  # Quit if login is closed

    def attempt_login():
        username = user_var.get()
        password = pass_entry.get()

        if username == "Guest" and password == "ifhiofees":
            login_win.destroy()
            root.deiconify()
        elif username in ["User1", "User2"] and password == "laguinitasidk":
            login_win.destroy()
            root.deiconify()
        else:
            messagebox.showerror("Login Failed", "Incorrect username or password.")

    tk.Label(login_win, text="Select User:").pack(pady=10)
    user_var = tk.StringVar(value="Guest")
    tk.OptionMenu(login_win, user_var, "Guest", "User1", "User2").pack()

    tk.Label(login_win, text="Enter Password:").pack(pady=10)
    pass_entry = tk.Entry(login_win, show="*")
    pass_entry.pack()

    tk.Button(login_win, text="Login", command=attempt_login).pack(pady=20)

def apply_theme():
    bg = "#222" if settings["dark_mode"] else "#fff"
    fg = "#fff" if settings["dark_mode"] else "#000"
    root.config(bg=bg)
    file_area.config(bg=bg)
    clock_label.config(bg=bg, fg=fg)
    settings_btn.config(bg=bg, fg=fg)
    plus_button.config(bg=bg, fg=fg)
    os_shadow.config(bg=bg)
    os_label.config(bg=bg)
    render_files()

def update_clock():
    clock_label.config(text=time.strftime("📅 %A, %B %d %Y\n🕒 %I:%M:%S %p"))
    root.after(1000, update_clock)

def settings_menu():
    global s_mode_enabled

    def toggle_dark():
        settings["dark_mode"] = var_dark.get()
        apply_theme()

    def toggle_smode():
        global s_mode_enabled
        s_mode_enabled = not s_mode_enabled
        state = "activated" if s_mode_enabled else "deactivated"
        messagebox.showinfo("S Mode", f"S-Mode {state}.")
        settings_win.destroy()

    settings_win = tk.Toplevel(root)
    settings_win.title("Settings")
    settings_win.geometry("250x300")
    bg = "#333" if settings["dark_mode"] else "#f0f0f0"
    settings_win.config(bg=bg)

    var_dark = tk.BooleanVar(value=settings["dark_mode"])
    tk.Checkbutton(settings_win, text="Enable Dark Mode", variable=var_dark,
                   command=toggle_dark, bg=bg).pack(pady=10)

    smode_text = "Disable S-Mode" if s_mode_enabled else "Activate S-Mode"
    tk.Button(settings_win, text=f"📘 {smode_text}", command=toggle_smode).pack(pady=5)

    if s_mode_enabled:
        tk.Button(settings_win, text="📐 Open Calculator", command=open_calculator).pack(pady=10)

def open_calculator():
    calc = tk.Toplevel(root)
    calc.title("School Calculator")
    calc.geometry("300x200")

    entry = tk.Entry(calc, font=("Courier", 14), justify="right")
    entry.pack(pady=10, padx=10, fill="x")

    def solve():
        try:
            result = eval(entry.get(), {"__builtins__": None}, {
                "sqrt": lambda x: x**0.5, "pow": pow, "abs": abs, "round": round
            })
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except Exception:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    tk.Button(calc, text="Calculate", command=solve).pack(pady=10)

def open_editor(fname):
    editor = tk.Toplevel(root)
    editor.title(f"Editing {fname}")
    editor.geometry("500x350")

    text_area = tk.Text(editor, wrap="word",
                        bg="#111" if settings["dark_mode"] else "#fff",
                        fg="#0f0" if settings["dark_mode"] else "#000",
                        insertbackground="#0f0" if settings["dark_mode"] else "#000")
    text_area.insert("1.0", files.get(fname, ""))
    text_area.pack(expand=True, fill="both", padx=10, pady=10)

    def confirm_save(event=None):
        response = messagebox.askyesno("Save File", "Save and close this file?")
        if response:
            files[fname] = text_area.get("1.0", "end-1c")
            editor.destroy()

    text_area.bind("<Control-s>", confirm_save)
    editor.protocol("WM_DELETE_WINDOW", lambda: confirm_save())

def create_file():
    if len(files) >= MAX_FILES:
        messagebox.showwarning("Limit Reached", f"Only {MAX_FILES} files allowed.")
        return

    name = simpledialog.askstring("File Name", "Enter a name (no extension):")
    ext = simpledialog.askstring("Extension", "Type '.txt' or '.pdf':")

    if not name or not ext or ext not in ALLOWED_EXTS:
        messagebox.showerror("Error", "Invalid name or extension.")
        return

    full_name = name + ext
    if full_name in files:
        messagebox.showwarning("Exists", "That file already exists.")
        return

    files[full_name] = ""
    file_positions[full_name] = (50 + 30 * len(files), 50)
    render_files()
    open_editor(full_name)

def render_files():
    for widget in file_area.winfo_children():
        widget.destroy()

    bg = "#222" if settings["dark_mode"] else "#fff"
    fg = "#fff" if settings["dark_mode"] else "#000"

    for fname in list(files.keys()):
        block = tk.Frame(file_area, bg=bg)
        icon = tk.Label(block, text="🗂️", font=("Arial", 20), bg=bg, fg=fg)
        label = tk.Label(block, text=fname, bg=bg, fg=fg)
        icon.pack()
        label.pack()

        x, y = file_positions.get(fname, (50, 50))
        block.place(x=x, y=y)

        def start_drag(event, b=block):
            b.startX = event.x
            b.startY = event.y

        def on_drag(event, b=block, f=fname):
            dx = event.x - b.startX
            dy = event.y - b.startY
            new_x = b.winfo_x() + dx
            new_y = b.winfo_y() + dy
            b.place(x=new_x, y=new_y)
            file_positions[f] = (new_x, new_y)

        block.bind("<Button-1>", start_drag)
        block.bind("<B1-Motion>", on_drag)

# --- Initialize Root and Launch Login ---
root = tk.Tk()
root.withdraw()
show_login()

# --- OS GUI Setup ---
root.title("GrayscaleTyperOS")
root.geometry("600x500")
root.resizable(False, False)

file_area = tk.Frame(root, width=580, height=340)
file_area.pack(pady=10)
file_area.pack_propagate(False)

plus_button = tk.Button(root, text="+ Create File", command=create_file)
plus_button.pack(pady=5)

settings_btn = tk.Button(root, text="⚙️ Settings", command=settings_menu)
settings_btn.pack(pady=5)

os_shadow = tk.Label(root, text="GrayscaleTyperOS", font=("Helvetica", 20, "bold"),
                     fg="#444", bg=root["bg"])
os_label = tk.Label(root, text="GrayscaleTyperOS", font=("Helvetica", 20, "bold"),
                    fg="#ccc", bg=root["bg"])
os_shadow.place(relx=0.5, rely=0.82, anchor="n", x=2, y=2)
os_label.place(relx=0.5, rely=0.82, anchor="n")

clock_label = tk.Label(root, text="", font=("Courier", 14))
clock_label.pack(side="bottom", pady=10)

apply_theme()
update_clock()
root.mainloop()
